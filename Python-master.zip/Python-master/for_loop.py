print("hello\n"*5,)

#for printing odd nos
print("Odd numbers are:")
for i in range(1,10,2):
    print(i, end=" ")

print("")
#reversse
print("Reverse order is:")
for i in range(10,0,-1):
    print(i, end=" ")
