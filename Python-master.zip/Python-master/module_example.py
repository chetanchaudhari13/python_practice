#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 18:23:51 2023

@author: dai
"""

import sys
sys.path.append(r"/home/dai/Desktop/CDAC/Python/Modules")

import module1 as m1
m1.f1()
m1.f2()