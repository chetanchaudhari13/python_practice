mk =30
sub= "java"
print("the marks are"+str(mk))
print("the marks are ",mk,sep=":")
print("the marks are {0} in {1} subject".format(mk,sub))
print("the marks are %d in %s subject" %(mk,sub))
print(f"the marks are {mk} in {sub} subject")

print("svsv",mk,"vsv")

print("hello", end=" ")
print("welcome")


print("%5d" %(123))
print("%5d" %(12345))

print("%9.2f" %(123.45))
print("%8.2f" %(123456.78))
