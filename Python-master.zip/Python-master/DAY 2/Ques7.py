sum=0
for i in range(0,20):
    n=int(input("Enter number: "))
    if n%2==0:
        sum=sum+n
print("Sum of only even numbers is: ",sum)