sum=0
for i in range(0,10):
    n=int(input("Enter a number: "))
    sum=sum+n
avg=sum/10
print("Average is: ",avg)