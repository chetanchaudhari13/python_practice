num = int(input("how many interation you want to print"))
sum=0
for i in range(1,num+1):
    sum= sum+((10**i)-1)
print(sum)    
    
