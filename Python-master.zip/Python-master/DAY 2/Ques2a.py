for i in range(0, 4):
    for k in range(0, i+1):
        print("*", end="")
    print()
