n=int(input("Enter the number:"))
if n%5==0 and n%11==0:
    print("Number is divisible by 5 and 11")
else:
    print("Not divisible by 5 and 11")