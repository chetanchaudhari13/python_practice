#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 18:17:55 2023

@author: dai
"""

def f11():
    print("Function 1")

def f12():
    print("Function 2")

if __name__=="__main__":
    f11()
    f12()