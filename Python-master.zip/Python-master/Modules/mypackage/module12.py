#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 18:17:55 2023

@author: dai
"""

def f21():
    print("Function 1")

def f22():
    print("Function 2")

if __name__=="__main__":
    f21()
    f22()