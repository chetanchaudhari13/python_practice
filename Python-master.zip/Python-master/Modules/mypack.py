#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 19:14:04 2023

@author: dai
"""

import mypackage.module11 as m1
import mypackage.module12 as m2

m1.f11()
m2.f22()
