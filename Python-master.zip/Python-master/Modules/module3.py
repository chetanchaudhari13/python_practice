#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 18:35:40 2023

@author: dai
"""

def f():
    print("This is a function")
    
if __name__=="__main__":
    f()