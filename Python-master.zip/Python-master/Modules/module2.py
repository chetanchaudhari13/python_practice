#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 18:20:48 2023

@author: dai
"""

import module1 as m1

m1.f1()
m1.f2()

from module1 import *
f1()
f2()

from module3 import *
f()

