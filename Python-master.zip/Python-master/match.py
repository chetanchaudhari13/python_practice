choice=int(input("ENter choice: "))
match choice:
    
    case 1:
        print("1")
    case 2:
        print("2")
