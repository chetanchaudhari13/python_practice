age= int(input("age: "))

if age<5:
    print("you are in the kinter garden")
elif age>=5 and age<10:
    print("5-10")
elif age>=10 and age<18:
    print("10-18")
elif age>99:
    print("time to die")
else:
    print("18+")
