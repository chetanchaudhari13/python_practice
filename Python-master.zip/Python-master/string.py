s = "this is the best"

print("Uppercase: ",s.upper())
print("lowercase: ",s.lower())
print("startswith: ",s.startswith("th"))
print("split:",s.split(" "))
print("Strip : ",s.strip("th"))
a="aaaa1234aaaa"
print("Strip: ", a.split('a'))
list=["my", "name", "is", "atharva"]
print(" ".join(list))
print("sh22df".isalpha())
print(s.replace("is","at"))