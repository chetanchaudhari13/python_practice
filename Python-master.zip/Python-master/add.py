x=int(input("Enter x="))
y=int(input("Enter y="))
print(x+y)
