dict = {"class":{"student":{"name":"Mike","marks":{"physics":70,"history":80}}}}
print(dict["class"]["student"]["marks"]["history"])

# for x,y in dict.items():
#     for i,j in y.items():
#         y.keys("marks")
#         print(y)


