sampleDict = {'a': 100, 'b': 200, 'c': 300,'d':200}
for x,y in sampleDict.items():
    if y==200:
        print(x)