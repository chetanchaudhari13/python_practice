keys = ['Ten', 'Twenty', 'Thirty']
values = [10, 20, 30]
d= {}
for i in range(len(keys)):
    d[keys[i]]= values[i]
print(d)
