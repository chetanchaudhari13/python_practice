sampleDict = {'Physics': 82,'Math': 65,'history': 75}
print(max(sampleDict, key=sampleDict.get))
