lst= [(0,"abc",11),(2,"def",22),(1,"ghi",33)]
lst.sort(key = lambda x:x[0])
print(lst)