lst=[1,2,3,4,5,6]
lst1=["python","advance","cdac"]
lst2=[1,2,45,6,[3,4,87,77],77]
print(lst2[4][3])
print(lst[3])
print(lst1[0][1:3])
print("Length of the list is: ",len(lst))

# lst[2]=66
# print(lst)
# print("*"*50)
# for  i in lst:
#     print(i)


# print("*"*50)
# lst3=[]
# k=0
# for i in range(5):
#     num=int(input("Enter the value in list:"))
#     lst3.append(num)
# print(lst3)

# print("*"*50)
# #add values of one list into anoter
# lst.extend(lst2)
# print(lst)
