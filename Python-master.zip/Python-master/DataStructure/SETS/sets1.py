sets ={1,2,3,4,5,6}
sets2= {10,20,30,40,1,2,3,100}
tup=(123,44,7,8)
sets.update(tup)
print(sets)

sets.add(77)
print(sets)

sets.pop()
print(sets)
s=set(["python","atharva"])
print(s)

se={12,22,43,22,(22,4)}
print(se)

s.add("tejas")
print(s)