def create_third_string(s1, s2):
    result = ''
    len_s1, len_s2 = len(s1), len(s2)
    min_len = min(len_s1, len_s2)
    print(min_len)
    for i in range(min_len):
        result += s1[i] + s2[len_s2 - i - 1]
    
    if len_s1 > len_s2:
        result += s1[min_len:]
    elif len_s2 > len_s1:
        result += s2[len_s2 - min_len::-1]
    
    return result

s1 = "hello"
s2 = "chetan"
third_string = create_third_string(s1, s2)
print(third_string)
