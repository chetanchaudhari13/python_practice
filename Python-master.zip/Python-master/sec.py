print("This s first python companf")

x=input("Enter number")
print(x)
