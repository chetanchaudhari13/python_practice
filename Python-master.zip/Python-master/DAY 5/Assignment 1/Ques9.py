list1 = [5, 10, 15, 20, 25, 50, 20]
list1[list1.index(20)]=200
print(list1)
