list1 = ["M", "na", "i", "Raj"]
list2 = ["y", "me", "s", "esh"]
print(list1)
for i in range(len(list1)):
    print(list1[i],list2[i],sep="",end=" ")
print()
list=[]
for i in range(len(list1)):
    list.append(list1[i]+list2[i])

print(list)