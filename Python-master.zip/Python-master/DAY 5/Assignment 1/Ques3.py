lst = [1, 2, 3, 4, 5, 6, 7]
for i in range(len(lst)):
    lst[i]=lst[i]**2
print(lst)

