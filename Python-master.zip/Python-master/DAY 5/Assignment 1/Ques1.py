aLsit = [100, 200, 300, 400, 500]
aLsit.reverse()
print(aLsit)