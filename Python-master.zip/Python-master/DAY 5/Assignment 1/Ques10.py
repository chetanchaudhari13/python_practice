lst=[5, 20, 15, 20, 25, 50, 20]
for i in lst:
    if i==20:
        lst.remove(20)
print(lst)
