list1 = ["Ashish", "", "Atharva", "Amit", "", "Revati"]
for i in list1:
    if i=="":
        list1.remove(i)
print(list1)

