s1 = 'ifatheare'
print(s1.find("t"))
print(s1[-2])
print(s1[3:8])
print(s1[0:5:-1])
print(s1[0:9])